Sanitized sample evidence bundle.
