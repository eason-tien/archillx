# System Delivery Portal

Generated: 2026-02-27T09:38:07.954620+00:00
Version: 0.44.0

## Recommended flow
- `README.md`
- `docs/SYSTEM_FINAL_DELIVERY.md`
- `DEPLOYMENT.md`
- `FINAL_RELEASE_CHECKLIST.md`
- `docs/OPERATIONS_RUNBOOK.md`

## Top Level
- [OK] `README.md`
- [OK] `DEPLOYMENT.md`
- [OK] `CHANGELOG.md`
- [OK] `RELEASE_NOTES_v0.44.0.md`
- [OK] `DELIVERY_MANIFEST.md`
- [OK] `FINAL_RELEASE_CHECKLIST.md`
- [OK] `docs/SYSTEM_FINAL_DELIVERY.md`
- [OK] `docs/SYSTEM_DELIVERY_INDEX.md`

## Operations
- [OK] `docs/OPERATIONS_RUNBOOK.md`
- [OK] `docs/RELEASE_ROLLBACK_RESTORE_RUNBOOK.md`
- [OK] `docs/SANDBOX_HOST_ENABLEMENT.md`
- [OK] `docs/GATE_SUMMARY_DASHBOARD.md`

## Evolution
- [OK] `docs/EVOLUTION_SUBSYSTEM.md`
- [MISSING] `docs/EVOLUTION_DELIVERY.md`
- [MISSING] `docs/EVOLUTION_DELIVERY_MANIFEST.md`
- [OK] `docs/EVOLUTION_GOVERNANCE.md`
- [OK] `docs/EVOLUTION_RUNBOOK.md`
- [OK] `docs/EVOLUTION_DASHBOARD.md`
- [OK] `docs/EVOLUTION_NAVIGATION.md`
- [OK] `docs/EVOLUTION_PORTAL.md`
- [OK] `docs/EVOLUTION_FINAL.md`

## Assets
- [OK] `deploy/grafana/archillx-dashboard.json`
- [OK] `.env.example`
- [OK] `.env.prod.example`
- [OK] `docker-compose.yml`
- [OK] `docker-compose.prod.yml`
